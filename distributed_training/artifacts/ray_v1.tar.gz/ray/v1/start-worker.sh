#!/bin/bash
set -m -e -o pipefail


echo "Starting ray worker"
echo $OCI__MAIN_IP

ray start --address=$OCI__MAIN_IP:3000 --min-worker-port=8700 --max-worker-port=8800


