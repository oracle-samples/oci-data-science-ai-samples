import os
#os.environ.setdefault("OCI_CONFIG_PROFILE","xyz")
os.environ.setdefault("OCIFS_CONFIG_PROFILE","abc")
profile = os.environ.get("OCI_CONFIG_PROFILE") or os.environ.get(
        "OCIFS_CONFIG_PROFILE"
    )
profile=profile or "DEFAULT"
print(profile)