import oci
import os
from urllib.parse import urlparse


def cleanup():
    config = oci.config.from_file(
        profile_name=os.environ.get("OCI_CONFIG_PROFILE", "DEFAULT")
    )
    client = oci.object_storage.ObjectStorageClient(config)
    if os.environ.get("OCI__WORK_DIR"):
        parsed = urlparse(os.environ["OCI__WORK_DIR"])
        bucket = parsed.username
        namespace = parsed.hostname
        prefix = os.path.join(parsed.path, os.environ.get("JOB_OCID", "Undefined"))[1:]
        print(f"{bucket}|{namespace}|{prefix}")
        res = client.list_objects(
            namespace_name=namespace, bucket_name=bucket, prefix=prefix
        )
        print(res.data)
        items = [data.name for data in res.data.objects]
        print(f"Found files: {items}")

        for file in items:
            try:
                delete_object_response = client.delete_object(
                    namespace_name=namespace, bucket_name=bucket, object_name=file
                )
            except:
                pass
            finally:
                print(delete_object_response.headers)


if __name__ == "__main__":
    cleanup()
