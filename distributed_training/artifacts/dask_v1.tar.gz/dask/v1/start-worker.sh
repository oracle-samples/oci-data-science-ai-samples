#!/bin/bash
set -m -e -o pipefail


echo "Starting dask worker with options: $@"

dask-worker $@ &


