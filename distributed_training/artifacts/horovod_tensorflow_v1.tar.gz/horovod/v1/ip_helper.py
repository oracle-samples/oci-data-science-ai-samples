import ipaddress
import os

import ads
import oci
import psutil
from ads.common import auth as authutil
from ads.jobs import Job


def find_self_ip():
    """
    Identify IP address by finding which of the host IP intersects with the CIDR block of the subnet associated with the JOB_OCID
    """
    authinfo = None
    if os.environ.get("OCI_IAM_TYPE", "resource_principal") == "resource_principal":
        authinfo = authutil.resource_principal()
    else:
        authinfo = authutil.api_keys()
    ads.set_auth(os.environ.get("OCI_IAM_TYPE", "resource_principal"))
    try:
        job_ocid = os.environ["JOB_OCID"]
        jobDef = Job.from_datascience_job(job_ocid)
        subnet_id = jobDef.infrastructure.subnet_id
        core_client = oci.core.VirtualNetworkClient(**authinfo)
        cidr = core_client.get_subnet(subnet_id).data.cidr_block
        ipset = [snics[0].address for interface, snics in psutil.net_if_addrs().items()]
        print(f"candidate IP addresses: {ipset}")

        for ip in ipset:
            if ipaddress.ip_address(ip) in ipaddress.ip_network(cidr):
                return ip
        return None
    except:
        return "127.0.0.1"  # ToDo correct. This bypasses IP check as local IP was fetched incorrectly.
