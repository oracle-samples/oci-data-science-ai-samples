#!/bin/bash --login
# The --login loads bash configuration required to enable conda correctly

# Launching using exec uses the same process
exec python /etc/datascience/horovod/run_horovod.py
$@