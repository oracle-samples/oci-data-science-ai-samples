export SYNC_DIR=logs/
export BUCKET=logs
export OB_PREFIX=test
export JOB_OCID=