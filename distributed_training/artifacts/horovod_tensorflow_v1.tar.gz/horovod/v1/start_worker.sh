#!/bin/bash

if [ "$SYNC_ARTIFACTS" = 1 ]; then
  echo "Starting sync job $SYNC_ARTIFACTS"
  bash ./sync.sh &
  echo "Started sync job $SYNC_ARTIFACTS"
else
  echo "skipping Sync $SYNC_ARTIFACTS"
fi

# Change IP address in /etc/hosts to host IP instead of container IP. This is a work around for horovod to work in v0.24.3
if [ -z "$USE_LOCAL_IP" ]; then
  WORKER_IP_ADDRESS=$(python -c "from ip_helper import find_self_ip; print(find_self_ip())")
  WORKER_HOST_NAME=$(uname -n)
  fgrep -v "$WORKER_HOST_NAME" /etc/hosts > /etc/hosts_edited
  echo "$WORKER_IP_ADDRESS $WORKER_HOST_NAME" >> /etc/hosts_edited
  cat /etc/hosts_edited > /etc/hosts
  rm /etc/hosts_edited
else
  echo "skipping ip update in hosts"
fi

/usr/sbin/sshd -p $WORKER_PORT