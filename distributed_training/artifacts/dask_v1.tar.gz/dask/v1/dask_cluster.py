#!/usr/bin/env python
# -*- coding: utf-8; -*-

# Copyright (c) 2022 Oracle and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl/

import json
import os
import subprocess
from time import sleep, time
from urllib.parse import urlparse

import ads
from ads.opctl.distributed.common.abstract_cluster_provider import ClusterProvider
import shlex


class DaskProvider(ClusterProvider):

    SCHEDULER_CMD = "/etc/datascience/dask/start-scheduler.sh"
    WORKER_CMD = "/etc/datascience/dask/start-worker.sh"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.download_certificate()
        self.code_execution_complete = False

    def download_certificate(self):
        print("checking environment variables for certificates information..")
        ca_ocid = os.environ.get("OCI__CERTIFICATE_AUTHORITY_OCID")
        cert_ocid = os.environ.get("OCI__CERTIFICATE_OCID")

        if not (ca_ocid and cert_ocid):
            print(
                f"Could not find both CA OCID: ({ca_ocid}) and Certificate OCID: ({cert_ocid}). Nothing to download."
            )
            return
        try:

            from ads.opctl.distributed.certificates import download_certificates

            self.ca_file_name = os.environ.get(
                "OCI__CA_DOWNLOAD_LOCATION", "/code/ca-cert.pem"
            )
            self.cert_file_name = os.environ.get(
                "OCI__CERTIFICATE_DOWNLOAD_LOCATION", "/code/cert.pem"
            )
            self.key_file_name = os.environ.get(
                "OCI__CERTIFICATE_KEY_DOWNLOAD_LOCATION", "/code/key.pem"
            )
            download_certificates(
                self.get_oci_auth(),
                self.ca_file_name,
                self.cert_file_name,
                self.key_file_name,
            )
        except:
            import traceback

            print(
                f"Cerificate Details - CA OCID: {ca_ocid}, cert_ocid: {cert_ocid}, ca_file_name: {self.ca_file_name}, cert_file_name: {self.cert_file_name}, key_file_name: {self.key_file_name}"
            )
            print(
                f"Could not download certificates.. You are using ads version {ads.__version__}. Considering upgrading to the latest."
            )
            traceback.print_exc()

    def configuration(self, conf: dict = {}) -> dict:
        dask_config = {**self.basic_configuration(), **conf}
        if self.mode == "MAIN":
            dask_config["SCHEDULER_IP"] = (
                f"tls://{dask_config['OCI__MAIN_IP']}"
                if "--tls-key" in os.environ.get("OCI__START_ARGS", "")
                else dask_config["OCI__MAIN_IP"]
            )
        dask_config["nprocs"] = os.environ.get("nprocs") or 1
        dask_config["death_timeout"] = os.environ.get("death_timeout", 10)
        return dask_config

    def setup_extra_configs(self, conf: dict):
        pass

    def create_dask_client(self):
        from distributed import Client

        sec = None
        if os.environ.get("SCHEDULER_IP", "").startswith("tls://") and hasattr(
            self, "ca_file_name"
        ):
            print("Creating TLS connection with Dask scheduler")

            from distributed.security import Security

            sec = Security(
                tls_ca_file=self.ca_file_name,
                tls_client_cert=self.cert_file_name,
                tls_client_key=self.key_file_name,
                require_encryption=True,
            )

        client = Client(
            f"{os.environ.get('SCHEDULER_IP')}:{os.environ.get('SCHEDULER_PORT', '8786')}",
            security=sec,
        )
        return client

    def check_cluster_status(self):
        from collections import namedtuple

        data = namedtuple("ClusterStatus", ["worker_count"])

        client = self.create_dask_client()
        worker_addresses = [addr for addr in client.scheduler_info()["workers"]]
        unique_worker_ips = set(
            map(
                lambda x: x.split(":")[0],
                [urlparse(addr).netloc for addr in worker_addresses],
            )
        )
        worker_count = len(unique_worker_ips)
        print(f"Worker IPs are: {unique_worker_ips}", flush=True)
        print(f"The worker count is: {worker_count}", flush=True)
        return data(worker_count=worker_count)

    def start_main(self):
        self.export_configuration(
            self.export_config_files()
        )  # Export the configuration details as environment variable
        print("About to run Subprocess for start main", flush=True)
        start_up_args = shlex.split(
            os.environ.get("OCI__START_ARGS", "")
        )  # SHell parser to split
        print(f"Scheduler startup option: {start_up_args}", flush=True)
        ret = subprocess.run([DaskProvider.SCHEDULER_CMD] + start_up_args)
        if ret.returncode != 0:
            raise Exception("Error Starting Main Process")
        print("Subprocess running for start main", flush=True)

    def start_worker(self):
        print("Starting Worker", flush=True)
        self.export_configuration(
            self.export_config_files()
        )  # Export the configuration details as environment variable
        print(
            f"Scheduler IP from env var is: {os.environ.get('OCI__MAIN_IP')}",
            flush=True,
        )

        start_up_args = shlex.split(
            os.environ.get("OCI__START_ARGS", "")
        )  # SHell parser to split
        print(f"Worker startup option: {start_up_args}", flush=True)
        ret = subprocess.run(
            [DaskProvider.WORKER_CMD]
            + [
                f"{os.environ.get('SCHEDULER_IP')}:{os.environ.get('SCHEDULER_PORT', '8786')}"
            ]
            + start_up_args
        )
        if ret.returncode != 0:
            raise Exception("Error Starting Worker Process")

    def runnable(self):
        """
        Dask cluster is ready for code execution if all the workers are available.
        The expected count of workers is available in the environment variable - `WORKER_COUNT`
        """
        try:
            status = self.check_cluster_status()  # Get worker count
        except Exception:
            print("Error checking cluster status", flush=True)
            raise Exception("Error checking the status of the cluster")
        return (
            status.worker_count == self.expected_worker_count()
            and not self.code_execution_complete
        )

    def run_code(self):
        """
        In case of DASK, code submission to the cluster is done from MAIN node.
        If Runnable, start python process. Update the execution state.
        While waiting to run, if the state becomes `tearable`, then stop
        """
        if self.mode == "MAIN":
            while True:
                if self.runnable():
                    print(
                        f"Cluster ready with {self.expected_worker_count()} workers. Begining code execution: `python {os.environ['OCI__ENTRY_SCRIPT']} {os.environ.get('OCI__ENTRY_SCRIPT_ARGS', '')} {os.environ.get('OCI__ENTRY_SCRIPT_KWARGS')}`",
                        flush=True,
                    )
                    subprocess_cmd = [
                        "python",
                        os.path.join("/code", os.environ["OCI__ENTRY_SCRIPT"]),
                    ]
                    subprocess_cmd += (
                        [
                            str(arg)
                            for arg in shlex.split(os.environ["OCI__ENTRY_SCRIPT_ARGS"])
                        ]
                        if os.environ.get("OCI__ENTRY_SCRIPT_ARGS")
                        else []
                    )

                    if os.environ.get("OCI__ENTRY_SCRIPT_KWARGS"):
                        subprocess_cmd += shlex.split(
                            os.environ["OCI__ENTRY_SCRIPT_KWARGS"]
                        )
                    print(f"Subprocess cmd: {subprocess_cmd}", flush=True)
                    ret = subprocess.run(subprocess_cmd)
                    self.code_execution_complete = True
                    if ret.returncode == 0:
                        return
                    else:
                        raise Exception(f"Code execution failed with exit code: {ret}")
                elif self.tearable():
                    break
                elif time() - self.start_time > self.time_out:
                    raise Exception(
                        f"Cluster not in `ready` state in {self.time_out} seconds. To change the timeout set env variable: `OCI__TIMEOUT` to desired value"
                    )
                else:
                    print(
                        f"Waiting for cluster to be in ready state for {time()-self.start_time} seconds. Time out: {self.time_out} seconds"
                    )
                    sleep(5)
        # exit(0)
