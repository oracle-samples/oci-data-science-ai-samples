import os
import subprocess
from time import sleep, time
from discover_workers import discover_hosts
from ads.opctl.distributed.common.abstract_cluster_provider import ClusterProvider
from urllib.parse import urlparse
import fsspec
from ads.jobs import Job
import ads


class HorovodProvider(ClusterProvider):

    def __init__(self, *args, **kwargs):
        print("ads version: ", ads.__version__)
        self.undefined_ocid = "Undefined"
        self.is_local = os.environ["JOB_OCID"] == self.undefined_ocid
        print("is_local: ", self.is_local)
        super().__init__(*args, **kwargs)
        self.code_execution_complete = False
        self.worker_port = os.environ.get("WORKER_PORT", "12345")

        self.get_np()

        self.start_timeout = str(max(int(os.environ.get("START_TIMEOUT", "600")), 600))
        self.horovod_args = os.environ.get("HOROVOD_ARGS")
        self.kwargs = os.environ.get("kwargs", os.environ.get("KWARGS"))
        self.training_script = os.environ["OCI__ENTRY_SCRIPT"]
        self.training_args = os.environ.get("OCI__ENTRY_SCRIPT_ARGS")
        self.enable_timeline = os.environ.get("ENABLE_TIMELINE")
        self.sync_dir = self.get_sync_dir(os.environ.get("OCI__SYNC_DIR"))
        print("sync dir:", self.sync_dir)
        self.stop_file_fail = "_".join([self.stop_file, "fail"])

    def get_sync_dir(self, sync_dir):
        if sync_dir:
            return sync_dir
        os.environ["OCI__SYNC_DIR"] = "/opt/ml"
        return os.environ["OCI__SYNC_DIR"]

    def stop(self):
        """
        Writes stop file and exits.
        """
        stop_file = self.stop_file_fail if self.execution_failure else self.stop_file
        with fsspec.open(stop_file, "w") as sf:
            sf.write("stop")
        sleep(20)


    def start(self):
        if self.mode == "MAIN":  # Check if the docker is started in scheduler mode
            print(f"Starting main scheduler process", flush=True)
            self.start_main()
        elif self.mode == "WORKER":  # Check if the docker is staretd in worker mode
            print(f"Starting worker process", flush=True)
            self.start_worker()
        else:
            print(f"Not a valid mode: {self.mode}", flush=True)
            raise Exception("Not a valid mode")

    def configuration(self, conf: dict = {}) -> dict:
        hvd_config = {**self.basic_configuration(), **conf}
        hvd_config["OCI__WORKER_IP"] = self.ip
        return hvd_config

    def check_cluster_status(self):
        print('checking cluster status', flush=True)
        workers = discover_hosts()
        print("received workers: ", workers, flush=True)
        cluster_ready = len(workers) >= int(self.num_workers) \
                        and not self.code_execution_complete
        print("cluster ready: ", cluster_ready, flush=True)
        return cluster_ready


    def run_code(self):
        """ This takes job run id and job_run from the node where job is running. Then runs horovodrun
        If Runnable, start python process. upate the execution state. While waiting to run, if the state becomes `tearable`, then stop
        """
        while True:
            if self.check_cluster_status():  # Now we need to run the horovod run command using subprocess
                # Make sure training happens on scheduler box too.
                self.start_worker()

                cmd = ["horovodrun",
                       "-np", self.np,
                       "-p", self.worker_port,
                       "--min-np", self.min_np,
                       "--max-np", self.max_np,
                       "--host-discovery-script", "/etc/datascience/horovod/discover-hosts.sh",
                       "--slots", self.slots,
                       "--start-timeout", self.start_timeout
                       ]

                if self.horovod_args:
                    print("adding horovod_args")
                    cmd += self.horovod_args.split()

                if self.kwargs:
                    print("adding kwargs")
                    cmd += self.kwargs.split()

                if self.enable_timeline == "1":
                    print("enable_timeline")
                    cmd.extend(["--timeline-filename", self.sync_dir + "/timeline.json"])

                training_cmd = ["python", self.training_script]
                cmd += training_cmd

                if self.training_args:
                    print("adding training_args")
                    cmd += self.training_args.split()

                print(cmd, flush=True)
                training_start_time = time()
                ret = subprocess.run(cmd)
                print("Training Time: ", time() - training_start_time, "seconds")

                if ret.returncode != 0:
                    raise Exception("horovodrun errored out...", ret)
                self.code_execution_complete = True
                break
            elif self.tearable():
                break
            elif time() - self.start_time > self.time_out:
                raise Exception(
                    f"Cluster not in `ready` state in {self.time_out} seconds. To change the timeout set env variable: `OCI__TIMEOUT` to desired value"
                )
            else:
                print(
                    f"Waiting for cluster to be in ready state for {time() - self.start_time} seconds. Time out: {self.time_out} seconds"
                )
                sleep(10)

    def start_main(self):
        print("start_scheduler")
        self.export_configuration(self.export_config_files())
        # Export the configuration details as environment variable
        self.run_code()


    def export_config_files(self):
        return [self.config_file]

    def start_worker(self):
        self.export_configuration(
            self.export_config_files())  # Export the configuration details as environment variable
        start_worker_file = "start_worker.sh"
        ret = subprocess.run(["sh", start_worker_file])
        print("Return code from the subprocess:", ret)
        if ret.returncode != 0:
            raise Exception("Error Starting Worker Process")
        if self.mode != "MAIN":
            self.worker()

    def worker(self):
        work_dir = self.work_dir
        jobDefID = self.jobDefID
        scheme = urlparse(self.work_dir).scheme
        authinfo = {}
        if scheme == "oci":
            authinfo = self.authinfo

        filesystem = fsspec.filesystem(scheme, **authinfo)  # FileSystem class corresponding to the URI scheme.
        path = f"{os.path.join(work_dir, jobDefID)}/stop"
        path_fail = f"{os.path.join(work_dir, jobDefID)}/stop_fail"
        path_scheduler_config= f"{os.path.join(work_dir, jobDefID)}/MAIN_config.json"
        while True:
            success = filesystem.glob(path)
            failure = filesystem.glob(path_fail)
            scheduler_config = filesystem.glob(path_scheduler_config)
            if len(success) > 0:
                print("Success stop file found. Exiting worker...", flush=True)
                break
            if len(failure) > 0:
                raise Exception("Failure stop file found. Exiting worker... Please check logs.")

            if len(scheduler_config) == 0 and time() - self.start_time > self.time_out:
                raise Exception(
                    f"Cluster not in `ready` state in {self.time_out} seconds. To change the timeout set env variable: `OCI__TIMEOUT` to desired value"
                )

            print("worker running...", flush=True)
            sleep(60)


    def find_self_ip(self, authinfo):
        if self.is_local:  # for docker-compose mode
            import socket
            hostname = socket.gethostname()
            IPAddr = socket.gethostbyname(hostname)
            print(f'local setup ip {IPAddr}')
            return IPAddr
        else:
            return super().find_self_ip(authinfo)

    def get_np(self):
        self.num_workers = int(self.expected_worker_count()) + 1  # for scheduler
        print("num_workers:", self.num_workers)

        self.derived_slot, self.derived_max_np = self.parse_shape(os.environ.get("SHAPE"))

        self.min_np = str(max(int(os.environ.get("MIN_NP", "1")), 1))
        print("min_np: ", self.min_np)

        self.max_np = os.environ.get("MAX_NP", self.derived_max_np)
        self.max_np = str(min(max(int(self.max_np), int(self.num_workers)), int(self.derived_max_np)))
        print("max_np: ", self.max_np)

        self.slots = str(min(max(int(os.environ.get("SLOTS", self.derived_slot)), 1), self.derived_slot))
        print("slots: ", self.slots)

        self.np = str(self.num_workers * int(self.slots))
        self.np = str(min(int(self.max_np), int(self.np)))
        print("np: ", self.np)

    def parse_shape(self, shape_var):
        if not self.is_local:
            try: 
                jobDef = Job.from_datascience_job(os.environ.get("JOB_OCID"))
                print("Shape from JobDef: ", jobDef.infrastructure.shape_name)
                slot = int(jobDef.infrastructure.shape_name.split('.')[2])
            except:
                print("Unable to parse shape from JobRun infrastructure. Deriving slot from Infra")
                import GPUtil
                gpus = GPUtil.getAvailable()
                print("gpu: ", gpus, "Count: ", len(gpus))
                slot = len(gpus)

            # No GPUs available. Implies CPU box
            if slot == 0:
                print("deriving slot from os")
                slot = os.cpu_count()

            # Finally fall back to shape variable received
            if slot == 0 and shape_var:
                print("Shape received:", shape_var)
                slot = int(shape_var.split('.')[2])
        else:
            slot = 1
        print("ocpus:", slot)
        max_np = str(int(self.num_workers) * slot)
        print("max_np:", max_np)
        return slot, max_np
