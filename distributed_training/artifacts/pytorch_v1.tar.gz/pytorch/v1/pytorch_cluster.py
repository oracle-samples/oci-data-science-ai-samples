import os
import psutil
import runpy
from ads.opctl.distributed.common.abstract_cluster_provider import ClusterProvider


class PyTorchProvider(ClusterProvider):
    def __init__(self, mode=None, ephemeral=False, life_span="0h", work_dir=""):
        mode = "MAIN" if str(os.environ["RANK"]) == "0" else "WORKER"
        super().__init__(mode, ephemeral, life_span, work_dir)

    def configuration(self, conf: dict = {}) -> dict:
        config = {
            "MASTER_ADDR" if self.mode == "MAIN" else "OCI__WORKER_IP": self.ip
        }
        return config

    def start(self):
        self.when_ready(self.export_configuration, [self.main_config_file])
        if not "LOCAL_RANK" in os.environ:
            os.environ["LOCAL_RANK"] = "0"

    def run_code(self):
        print(f"MASTER_ADDR: {os.environ['MASTER_ADDR']}")
        if 'MASTER_PORT' not in os.environ:
            os.environ['MASTER_PORT'] = "29400"
        print(f"MASTER_PORT: {os.environ.get('MASTER_PORT')}")
        if 'OCI__WORKER_COUNT' in os.environ:
            os.environ["WORLD_SIZE"] = str(int(os.environ['OCI__WORKER_COUNT']) + 1)
        print(f"WORLD_SIZE: {os.environ.get('WORLD_SIZE')}")
        print(f"RANK: {os.environ['RANK']}", flush=True)
        runpy.run_path(os.path.join("/code", os.environ["OCI__ENTRY_SCRIPT"]), run_name="__main__")
        self.code_execution_complete = True
