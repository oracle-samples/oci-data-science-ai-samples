#!/bin/bash --login

export PYTHONPATH=$PYTHONPATH:/etc/datascience
python /etc/datascience/run.py

exit $LastExitCode


