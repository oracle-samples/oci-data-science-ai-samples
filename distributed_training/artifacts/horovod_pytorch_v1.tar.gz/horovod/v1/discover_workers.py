import json
import os
from urllib.parse import urlparse

import fsspec, ads
from ads.common import auth as authutil

def get_oci_auth():
    profile = os.environ.get("OCI_CONFIG_PROFILE") or os.environ.get(
        "OCIFS_CONFIG_PROFILE"
    )
    ads.set_auth(
        os.environ.get("OCI_IAM_TYPE", "resource_principal"),
        profile=profile or "DEFAULT",
    )
    authinfo = ads.common.auth.default_signer()
    return authinfo

def discover_hosts():

    # Can't have any logging here. horovod breaks as it thinks they're all IPs
    work_dir = os.environ.get("OCI__WORK_DIR")
    jobDefID = os.environ.get("JOB_OCID")
    scheme = urlparse(work_dir).scheme
    authinfo = {}
    if scheme == "oci":
        authinfo = get_oci_auth()

    filesystem = fsspec.filesystem(scheme, **authinfo)  # FileSystem class corresponding to the URI scheme.

    path=f"{os.path.join(work_dir,jobDefID)}/*config.json"
    files = filesystem.glob(path)

    discover_host_dict = {}  # For providing IPs to horovodrun
    worker_slot_dict = {} # For providing slots for cluster readiness check
    for file in files:
        with filesystem.open(file, 'rb') as wcf:
            cfg_json = json.loads(wcf.read())
            discover_host_dict.setdefault(cfg_json['OCI__WORKER_IP'], cfg_json['OCI__SLOTS'])
            worker_slot_dict.setdefault(cfg_json['OCI__WORKER_IP'], int(cfg_json['OCI__SLOTS']))

    print('\n'.join(map(':'.join, discover_host_dict.items())))
    return worker_slot_dict

if __name__ == '__main__':
    # os.environ["OCI_IAM_TYPE"] = "api_key"
    # os.environ["WORK_DIR"] = "oci://dls-bucket@bigdatadatasciencelarge/daskcluster-testing/001"
    # os.environ["JOB_OCID"] = "ocid1.datasciencejob.oc1.iad.amaaaaaanif7xwiabcsocnzncbnn2g6vodld7e2gl24bhrxyaxb3363yz27a"
    ips = discover_hosts()