
## Horovod Workloads


### Steps to execute a Horovod Workload
#### 1. Modify Training Scripts for Elastic Horovod
Refer examples from
* https://github.com/horovod/horovod/tree/master/examples/elastic
 
#### 2. Build and Push Docker image
* Build docker image with a 'build-arg' called 'CODE_DIR'. This will place the contents of the specified folder(user's training code files) inside /code directory of the image.
  <br>**Note**: By default, it will place all files inside the directory that houses `oci_dist_training_artifacts` in the docker image's `/code` dir.
* For example, if the user has the code inside 'code' directory (alongside `oci_dist_training_artifacts`)
  docker build-arg will be something like ``docker build --build-arg CODE_DIR=code``
* Location of Docker files. (There are two, for cpu and for gpu)
    - oci_dist_training_artifacts/horovod/v1/docker/tensorflow.gpu.Dockerfile
    - oci_dist_training_artifacts/horovod/v1/docker/tensorflow.cpu.Dockerfile
  
* Location of Docker files for Pytorch
    -  oci_dist_training_artifacts/horovod/v1/docker/pytorch.gpu.Dockerfile
    -  oci_dist_training_artifacts/horovod/v1/docker/pytorch.cpu.Dockerfile
  
* Full Docker build command
    - `docker build --build-arg CODE_DIR=code -t <image_full_repo_path> -f oci_dist_training_artifacts/horovod/v1/docker/tensorflow.gpu.Dockerfile .`
    - we use full image_full_repo_path so that it can pushed to ocir.
    - Example `docker build --build-arg CODE_DIR=mycode -t iad.ocir.io/my_tenancy/my_repo/my_hvd_img:1.0 -f oci_dist_training_artifacts/horovod/v1/docker/tensorflow.gpu.Dockerfile .`
        - `my_tenancy` is the tenancy name. 
        - `my_repo` is the repo name.
        - `my_hvd_img:1.0` is the image name.
* Push the image to ocir using: <br> `docker push iad.ocir.io/my_tenancy/my_repo/my_hvd_img:1.0`


#### 3. Define the jobrun spec file.
* Jobrun spec file (YAML) defines the cluster, infrastructure and environment variables required for the framework(Horovod)
* Basically, it manifests: 
  - the job run properties
  - which docker image to run.  
  - Infrastructure. Shapes, subnet ,project Ids etc
  - cluster size.  
  - Location of the user's training script (plus data) that needs to be executed.(inside /code/*)
  - Any args that the user's training script requires. Example:
  - Framework(Horovod) related properties.
  - Where to upload model checkpoints, tensorboard logs.
* Example
```yaml
kind: distributed
apiVersion: v1.0
spec:
  infrastructure: # This section maps to Job definition. Does not include environment variables
    kind: infrastructure
    type: dataScienceJob
    apiVersion: v1.0
    spec:
      projectId: oci.xxxx.<project_ocid> #datascience project id
      compartmentId: oci.xxxx.<compartment_ocid> 
      displayName: "horovod_dev_tf"
      logGroupId: oci.xxxx.<log_group_ocid>
      subnetId: oci.xxxx.<subnet-ocid> 
      shapeName: VM.GPU2.1
      blockStorageSize: 50
  cluster:
    kind: HOROVOD
    apiVersion: v1.0
    spec:
      image: "iad.ocir.io/<tenancy_id>/<repo_name>/<image_name>:<image_tag>"
      workDir:  "oci://<bucket_name>@<bucket_namespace>/<bucket_prefix>"
      name: "horovod_tf"
      config:
        env:
          # MIN_NP, MAX_NP and SLOTS are inferred from the shape. Modify only when needed.
#          - name: MIN_NP
#            value: 2
#          - name: MAX_NP
#            value: 4
#          - name: SLOTS
#            value: 2
          - name: WORKER_PORT
            value: 12345
          - name: START_TIMEOUT #Optional: Defaults to 600.
            value: 600
          - name: ENABLE_TIMELINE # Optional: Disabled by Default.Significantly increases training duration if switched on (1).
            value: 0
          - name: SYNC_ARTIFACTS #Mandatory: Switched on by Default.
            value: 1
          - name: WORKSPACE #Mandatory if SYNC_ARTIFACTS==1: Destination object bucket to sync generated artifacts to.
            value: "jobs"
          - name: WORKSPACE_PREFIX #Mandatory if SYNC_ARTIFACTS==1: Destination object bucket folder to sync generated artifacts to.
            value: "example/odsc_jobs_experiments"
          - name: HOROVOD_ARGS # Parameters for cluster tuning.
            value: "--verbose"
      main:
        name: "scheduler"
        replicas: 1 #this will be always 1
      worker:
        name: "worker"
        replicas: 2 #number of workers
  runtime:
    kind: python
    apiVersion: v1.0
    spec:
      entryPoint: "/code/train.py" #location of user's training script in docker image.
      args:
          - --data-dir    #any arguments that the training script requires.
          - /code/data/mnist.npz
      env:

```
* Usually, the following variables need to be changed
    - `projectId`
    - `compartmentId`
    -  `logGroupId`
    -  `subnetId`
    - `shapeName`
    - `image`
    - `workDir`
    - `WORKSPACE`
    - `HOROVOD_ARGS`
    - `worker replicas` <br><br>
  
* Save the yaml file to workspace directory.<br> Example: `train.yaml`

#### 4. Launch the job.
* `ads opctl run -f train.yaml`
* This creates the job and the job runs based on the cluster size.

#### 5. Monitor
* Monitor job runs using <br> `ads jobs watch <scheduler jobrun_id>`
* Incase your training script is writing tensorboard logs/model checkpoints and you have configured 'sync'
  (which basically means that you write logs, checkpoints to a local folder passed on as `OCI__SYNC_DIR==/opt/ml` environment variable) the sync process will sync the folder to the configured
  object storage location. You can then connect a local tensorboard console to monitor the training process.
  Example:<br>
  `OCIFS_IAM_TYPE=api_key tensorboard --logdir oci://<bucket_name>/<bucket_prefix>/logs`
