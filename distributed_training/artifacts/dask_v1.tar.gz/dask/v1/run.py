from ads.opctl.distributed.common.cluster_runner import ClusterRunner
from ads.opctl.distributed.common.cluster_provider_factory import ClusterProviderFactory
from dask_cluster import DaskProvider

if __name__ == "__main__":
    ClusterProviderFactory.register("DASK", DaskProvider)
    ClusterRunner().run()
