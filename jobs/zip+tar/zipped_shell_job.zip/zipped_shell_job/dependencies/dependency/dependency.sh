#!/bin/bash

function Function(){
  echo "Successfully calling from dependency in nested dependency from dependency1 directory.."
}