#!/usr/bin/env python
# -*- coding: utf-8; -*-

# Copyright (c) 2022 Oracle and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl/

import os
import shlex
import subprocess
from time import sleep, time

from ads.opctl.distributed.common.abstract_cluster_provider import ClusterProvider


class RayProvider(ClusterProvider):

    HEAD_CMD = "/etc/datascience/ray/start-head.sh"
    WORKER_CMD = "/etc/datascience/ray/start-worker.sh"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.code_execution_complete = False

    def configuration(self, conf: dict = {}) -> dict:
        ray_config = {**self.basic_configuration(), **conf}
        if self.mode == "MAIN":
            ray_config["HEAD_IP"] = ray_config["OCI__MAIN_IP"]
        return ray_config

    def setup_extra_configs(self, conf: dict):
        pass

    def check_cluster_status(self):
        from collections import namedtuple

        import ray

        ray.init(address="auto", ignore_reinit_error=True)
        data = namedtuple("ClusterStatus", ["worker_count"])
        full_status = ray.nodes()
        worker_count = 0
        ips = []
        for status in full_status:
            if status["Alive"]:
                worker_count += 1
                ips.append(status["NodeManagerAddress"])
        print(f"Node IPs are: {ips}", flush=True)
        print(f"The node count is: {worker_count}", flush=True)
        return data(worker_count=worker_count - 1)

    def start_main(self):
        self.export_configuration(
            self.export_config_files()
        )  # Export the configuration details as environment variable
        print("About to run Subprocess for start main", flush=True)
        start_up_args = shlex.split(os.environ.get("OCI__START_ARGS", ""))  # SHell parser to split
        print(f"Head node startup option: {start_up_args}", flush=True)
        ret = subprocess.run([RayProvider.HEAD_CMD] + start_up_args)
        if ret.returncode != 0:
            raise Exception("Error Starting Main Process")
        print("Subprocess running for start main", flush=True)

    def start_worker(self):
        print("Starting Worker", flush=True)
        self.export_configuration(
            self.export_config_files()
        )  # Export the configuration details as environment variable
        print(
            f"Head node IP from env var is: {os.environ.get('OCI__MAIN_IP')}",
            flush=True,
        )

        start_up_args = shlex.split(os.environ.get("OCI__START_ARGS", ""))  # SHell parser to split
        print(f"Worker startup option: {start_up_args}", flush=True)
        ret = subprocess.run([RayProvider.WORKER_CMD] + start_up_args)
        if ret.returncode != 0:
            raise Exception("Error Starting Worker Process")

    def runnable(self):
        """
        Ray cluster is ready for code execution if all the workers are available.
        The expected count of workers is available in the environment variable - `WORKER_COUNT`
        """
        try:
            status = self.check_cluster_status()  # Get worker count
        except Exception:
            print("Error checking cluster status", flush=True)
            raise Exception("Error checking the status of the cluster")
        return (
            status.worker_count == self.expected_worker_count() and not self.code_execution_complete
        )

    def run_code(self):
        """
        In case of RAY, code submission to the cluster can be done from any node.
        If Runnable, start python process. Update the execution state.
        While waiting to run, if the state becomes `tearable`, then stop
        """
        # TODO: check if it works without the if condition
        if self.mode == "MAIN":
            while True:
                if self.runnable():
                    print(
                        f"Cluster ready with {self.expected_worker_count()} workers. Begining code execution: `python {os.environ['OCI__ENTRY_SCRIPT']} {os.environ.get('OCI__ENTRY_SCRIPT_ARGS', '')} {os.environ.get('OCI__ENTRY_SCRIPT_KWARGS')}`",
                        flush=True,
                    )
                    subprocess_cmd = [
                        "python",
                        os.path.join("/code", os.environ["OCI__ENTRY_SCRIPT"]),
                    ]
                    subprocess_cmd += (
                        [str(arg) for arg in shlex.split(os.environ["OCI__ENTRY_SCRIPT_ARGS"])]
                        if os.environ.get("OCI__ENTRY_SCRIPT_ARGS")
                        else []
                    )

                    if os.environ.get("OCI__ENTRY_SCRIPT_KWARGS"):
                        subprocess_cmd += shlex.split(os.environ["OCI__ENTRY_SCRIPT_KWARGS"])
                    print(f"Subprocess cmd: {subprocess_cmd}", flush=True)
                    ret = subprocess.run(subprocess_cmd)
                    self.code_execution_complete = True
                    if ret.returncode == 0:
                        return
                    else:
                        raise Exception(f"Code execution failed with exit code: {ret}")
                elif self.tearable():
                    break
                elif time() - self.start_time > self.time_out:
                    raise Exception(
                        f"Cluster not in `ready` state in {self.time_out} seconds. To change the timeout set env variable: `OCI__TIMEOUT` to desired value"
                    )
                else:
                    print(
                        f"Waiting for cluster to be in ready state for {time()-self.start_time} seconds. Time out: {self.time_out} seconds"
                    )
                    sleep(5)
        # exit(0)
