#!/bin/bash

echo "Successfully calling from dependency in child directory.."