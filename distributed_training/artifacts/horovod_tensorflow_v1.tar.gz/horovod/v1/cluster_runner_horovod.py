import os
from time import sleep
from ads.opctl.distributed.common.cluster_runner import ClusterRunner
import traceback

class ClusterRunnerHorovod(ClusterRunner):
    def set_environment_variables(self):
        os.environ["JOB_OCID"] = os.environ.get("JOB_OCID", 'Undefined')
        print("Job Ocid:", os.environ["JOB_OCID"])

    def __init__(self, cluster_provider=None, cluster_key=None):
        self.set_environment_variables()
        super().__init__(cluster_provider, cluster_key)
        print("Cluster Config: ", self.cluster_key, self.mode, self.ephemeral, self.work_dir)


    def run(self):
        exit_code = 0
        try:
            self.cluster.start()
            # self.cluster.code_execution_complete = True # This needs to be
            # set inside the run_code method of the implementation class.
        except Exception as e:
            print(f"Error Running the code: {e}", flush=True)
            traceback.print_exc()
            exit_code = 1
            self.cluster.execution_failed()
        while (
                not self.cluster.tearable()
        ):  # If not ephemeral, wait util it is ready for tearing down
            sleep(15)
        print("Signalling Stop!!!", flush=True)
        self.cluster.stop()  # Signal cluster tear down
        print(f"Exiting with exit code: {exit_code}", flush=True)
        exit(exit_code)



if __name__ == "__main__":
    ClusterRunner().run()