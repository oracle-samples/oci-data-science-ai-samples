import pandas as pd

# import the helper functions
from mlpipeline_data_helpers import MLPipelineDataHelper

print("Job started")

print("Before set_pipeline_param")
# pass a simple value to the next step
MLPipelineDataHelper.set_pipeline_param('NUMBER_OF_WORKERS', '4')

print("After set_pipeline_param")
