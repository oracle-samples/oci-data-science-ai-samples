UNDEFINED_OCID = "Undefined"
DEFAULT_WORKER_PORT = "12345"
DEFAULT_WORKER_COUNT = 0

TF_CONFIG_BASE = {
    'cluster': {
        'worker': []
    },
    'task': {'type': 'worker', 'index': 0}
}

TF_CONFIG_PS = {
    "cluster": {
        'worker': [],
        "ps": []
    },
    "task": {"type": "", "index": 0}
}



