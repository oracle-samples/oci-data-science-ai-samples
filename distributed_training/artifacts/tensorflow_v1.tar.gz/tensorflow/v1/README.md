# Developer Guide

Please refer 
1. https://github.com/oracle-samples/oci-data-science-ai-samples/tree/master/distributed_training
2. https://github.com/oracle-samples/oci-data-science-ai-samples/blob/master/distributed_training/tensorflow.md