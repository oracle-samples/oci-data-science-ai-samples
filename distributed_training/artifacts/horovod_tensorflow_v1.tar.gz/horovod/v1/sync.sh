#!/bin/bash

#todo: Restrict this script to rank-0 worker.
sleep_duration=30

if [ "$JOB_OCID" = 'Undefined' ]; then
  auth_method=api_key
else
  auth_method=resource_principal
fi
echo "auth method: $auth_method"
echo "OCI__SYNC_DIR dir: $OCI__SYNC_DIR"

while true; do
  if [[ -d $OCI__SYNC_DIR && -n "$(ls -A $OCI__SYNC_DIR)" ]]; then
    echo "directory exists and data present..syncing"
    /root/bin/oci os object sync --auth $auth_method --bucket-name $WORKSPACE --prefix $WORKSPACE_PREFIX/$JOB_OCID/ --src-dir $OCI__SYNC_DIR
  else
    echo "nothing to sync in $OCI__SYNC_DIR"
  fi
  sleep $sleep_duration
done
