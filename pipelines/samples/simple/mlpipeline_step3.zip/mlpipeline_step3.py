import pandas as pd
import os, io
import ads
from ads import set_auth
from ads.common.auth import default_signer
ads.set_auth(auth="resource_principal")

# import the helper functions
from mlpipeline_data_helpers import MLPipelineDataHelper

# get the parameter and read the file
workers_filename = MLPipelineDataHelper.get_pipeline_param('WORKERS_DATA_FILENAME')
workers_file = os.environ["DATA_LOCATION"] + workers_filename
try:
    workers_data_dfrm = pd.read_csv(workers_file, storage_options=default_signer())    
except FileNotFoundError:
    print(workers_file + " file not found")

print(workers_data_dfrm)
