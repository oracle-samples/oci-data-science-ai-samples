#ps -ef | grep 'param_server_example' | grep -v grep | awk '{print $2}' | xargs -r kill -9
kill -9 $(lsof -t -i tcp:12345)
kill -9 $(lsof -t -i tcp:12346)
kill -9 $(lsof -t -i tcp:12347)

echo "cmd: $1";

#worker
echo 'starting worker'
TF_CONFIG="{\"cluster\":{\"worker\":[\"localhost:12345\"],\"ps\":[\"localhost:12346\"],\"chief\":[\"localhost:12347\"]},\"task\":{\"type\":\"worker\",\"index\":0}}" python $1 &

sleep 10
echo 'parameter server'
TF_CONFIG="{\"cluster\":{\"worker\":[\"localhost:12345\"],\"ps\":[\"localhost:12346\"],\"chief\":[\"localhost:12347\"]},\"task\":{\"type\":\"ps\",\"index\":0}}" python $1 &

sleep 10
echo 'coordinator'
TF_CONFIG="{\"cluster\":{\"worker\":[\"localhost:12345\"],\"ps\":[\"localhost:12346\"],\"chief\":[\"localhost:12347\"]},\"task\":{\"type\":\"chief\",\"index\":0}}" python $1

