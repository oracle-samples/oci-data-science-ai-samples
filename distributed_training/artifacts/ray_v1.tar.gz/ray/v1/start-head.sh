#!/bin/bash
set -m -e -o pipefail


export PYTHONPATH=/code
echo $OCI__MAIN_IP

ray start --head --port=3000

