import os
import shlex
import subprocess
from time import time, sleep
import runpy
from ads.opctl.distributed.common.abstract_cluster_provider import ClusterProvider

UNDEFINED_OCID = "Undefined"
class PyTorchProvider(ClusterProvider):
    def __init__(self, mode=None, ephemeral=False, life_span="0h", work_dir=""):
        mode = "MAIN" if str(os.environ["RANK"]) == "0" else "WORKER"
        super().__init__(mode, ephemeral, life_span, work_dir)

    def configuration(self, conf: dict = {}) -> dict:
        config = {
            "MASTER_ADDR" if self.mode == "MAIN" else "OCI__WORKER_IP": self.ip
        }
        return config

    def start(self):
        self.when_ready(self.export_configuration, [self.main_config_file])
        if not "LOCAL_RANK" in os.environ:
            os.environ["LOCAL_RANK"] = "0"

    def find_self_ip(self, authinfo):
        if os.environ["JOB_OCID"] == UNDEFINED_OCID:  # for docker-compose mode
            import socket
            hostname = socket.gethostname()
            IPAddr = socket.gethostbyname(hostname)
            print(f'local setup ip {IPAddr}')
            return IPAddr
        else:
            return super().find_self_ip(authinfo)

    def run_code(self):
        print(f"MASTER_ADDR: {os.environ['MASTER_ADDR']}")
        if 'MASTER_PORT' not in os.environ:
            os.environ['MASTER_PORT'] = "29400"
        print(f"MASTER_PORT: {os.environ.get('MASTER_PORT')}")
        if 'OCI__WORKER_COUNT' in os.environ:
            os.environ["WORLD_SIZE"] = str(int(os.environ['OCI__WORKER_COUNT']) + 1)
        print(f"WORLD_SIZE: {os.environ.get('WORLD_SIZE')}")
        print(f"RANK: {os.environ['RANK']}", flush=True)
        code_dir = os.environ.get("OCI__CODE_DIR", "/code")
        training_sript = os.path.join(code_dir, os.environ["OCI__ENTRY_SCRIPT"])

        cmd = self.profile_cmd()
        cmd.extend(["python", training_sript])
        args = os.environ.get("OCI__ENTRY_SCRIPT_ARGS")
        if args:
            cmd += shlex.split(args)

        print("Running: ", ' '.join(cmd), flush=True)
        training_start_time = time()
        ret = subprocess.run(cmd)
        if ret.returncode != 0:
            raise Exception("Pytorch distributed errored out...", ret)
        else:
            print("Training Time: ", time() - training_start_time, "seconds")
        self.code_execution_complete = True

    def profile_cmd(self):
        profile = os.environ.get("PROFILE", '0')
        cmd = []
        if profile == '1':
            print("Profiler ON")
            cmd = os.environ.get("PROFILE_CMD").split(' ')
        return cmd

    # TODO: Move this to ads ClusterProvider
    def sync(self, loop=True):
        super().sync(loop)
        if not loop:
            sleep_duration = int(os.environ.get("POST_PROCESSING_WAIT", 60))
            print(f"post processing wait..{sleep_duration} seconds")
            sleep(sleep_duration)
            print("..")

