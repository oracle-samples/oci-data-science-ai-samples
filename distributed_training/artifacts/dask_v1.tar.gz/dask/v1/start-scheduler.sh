#!/bin/bash
set -m -e -o pipefail


export PYTHONPATH=/code

dask-scheduler --host 0.0.0.0 --pid-file /etc/datascience/main_pid.txt $@ &

export MAIN_PID=$(</etc/datascience/main_pid.txt)

echo "main pid $MAIN_PID"

