# ===========================================================
# Employee attrition pipeline sample - training logistic regression step
#
# dependencies:
#    mlpipeline_data_helpers.py - helper functions to transfer data between steps
#
# Environment variables required:
#     DATA_LOCATION - Object storage bucket to use for temporary data transfer between steps
# 
# optional environment variables:
#     SKIP_MODEL_SAVE - to skip saving the model to the model catalog (for development phase)
# ============================================================

import sys
import subprocess

# update ADS
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'oracle-ads==2.6.1', '--upgrade'])

# update onnxconverter_common:
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'onnxconverter_common==1.9.0', '--upgrade'])

import io
import logging
import os
from os import path 

import ads 
print("ADS version: ", ads.__version__)

import pandas as pd
import numpy as np

from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import RandomizedSearchCV
from sklearn.model_selection import ShuffleSplit
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import auc, roc_auc_score, roc_curve, recall_score, log_loss

from ads.model.generic_model import GenericModel
from ads.common.model_metadata import UseCaseType
from ads.common.model_metadata import MetadataCustomCategory
from ads.common.auth import default_signer

def set_signer():
    RP = os.environ.get("OCI_RESOURCE_PRINCIPAL_VERSION", "UNDEFINED")
    if not RP or RP == "UNDEFINED":
        # Use api_key with config file
        print("using API key for auth")
        ads.set_auth(auth="api_key")
    else:
        # Use resource principal
        print("using Resource Principal for auth")
        ads.set_auth(auth="resource_principal")

        
set_signer()

# read the data
from mlpipeline_data_helpers import MLPipelineDataHelper

x_train_filename = MLPipelineDataHelper.get_pipeline_param('X_TRAIN_FILENAME')
try:
    X_train = pd.read_csv(x_train_filename, storage_options=default_signer())    
except FileNotFoundError:
    print(x_train_filename + " file not found")
    
y_train_filename = MLPipelineDataHelper.get_pipeline_param('Y_TRAIN_FILENAME')
try:
    y_train = np.ravel(pd.read_csv(y_train_filename, storage_options=default_signer()))
except FileNotFoundError:
    print(y_train_filename + " file not found")

x_test_filename = MLPipelineDataHelper.get_pipeline_param('X_TEST_FILENAME')
try:
    X_test = pd.read_csv(x_test_filename, storage_options=default_signer())    
except FileNotFoundError:
    print(x_test_filename + " file not found")

y_test_filename = MLPipelineDataHelper.get_pipeline_param('Y_TEST_FILENAME')
try:
    y_test = pd.read_csv(y_test_filename, storage_options=default_signer())    
except FileNotFoundError:
    print(y_test_filename + " file not found")

# Train Logistic Regression model
kfold = model_selection.KFold(n_splits=10)

modelCV = LogisticRegression(solver='liblinear',
                             class_weight="balanced", 
                             random_state=7)

results = model_selection.cross_val_score(
    modelCV, X_train, y_train, cv=kfold, scoring='roc_auc')

print("AUC score (CV only): %.2f (%.2f)" % (results.mean(), results.std()))

print("Running grid search and fitting the model...")
param_grid = {'C': np.arange(1e-03, 2, 0.01)} # hyper-parameter list to fine-tune
log_gs = GridSearchCV(LogisticRegression(solver='liblinear', # setting GridSearchCV
                                         class_weight="balanced", 
                                         random_state=7),
                      return_train_score=True,
                      param_grid=param_grid,
                      scoring='roc_auc',
                      cv=10)

log_grid = log_gs.fit(X_train, y_train)
log_opt = log_grid.best_estimator_
results = log_gs.cv_results_

log_opt.fit(X_train, y_train) # fit optimised model to the training data
lr_probs = log_opt.predict_proba(X_test) # predict probabilities
lr_probs = lr_probs[:, 1] # we will only keep probabilities associated with the employee leaving
logit_roc_auc = roc_auc_score(y_test, lr_probs) # calculate AUC score using test dataset
print('AUC score (after model fit): %.3f' % logit_roc_auc)

# Saving the model to the model catalog
from ads.common.model_artifact import ModelArtifact
from ads.common.model_export_util import prepare_generic_model
import joblib 

# Path to artifact directory for my sklearn model: 
lr_model_path = "./model-artifact-lr/"

# Creating the artifact template files in the directory: 
lr_model_artifact = prepare_generic_model(lr_model_path, 
                                         function_artifacts=False, 
                                         data_science_env=True,
                                         force_overwrite=True)

# Creating a joblib pickle object of my random forest model: 
joblib.dump(log_opt, os.path.join(lr_model_path, "model.joblib"))

lr_model = GenericModel(
    estimator=log_opt, 
    artifact_dir=lr_model_path
)
lr_model.prepare(
    inference_conda_env="generalml_p37_cpu_v1",
    training_conda_env="generalml_p37_cpu_v1",
    use_case_type=UseCaseType.BINARY_CLASSIFICATION,
    X_sample=X_train,
    y_sample=y_train,
    force_overwrite=True
)

# set the AUC score on the model metadata
lr_model.metadata_custom.add(key='AUC', value=f"{logit_roc_auc}", category=MetadataCustomCategory.PERFORMANCE, replace=True)

# check if need to skip saving the model to the model catalog
if os.environ.get("SKIP_MODEL_SAVE") is not None and os.environ["SKIP_MODEL_SAVE"] == "True":
    print("Skipping model save to catalog")
    exit()

pipelinerun_id = os.environ['PIPELINE_RUN_OCID']
compartment_id = os.environ['PIPELINE_COMPARTMENT_OCID']
project_id = os.environ['PIPELINE_PROJECT_OCID']

# save the model to the catalog
lr_model_displayname = "employee-attr-lr"
lr_model_description = "Logistic Regression model for employee attrition dataset"
print(f"Saving model {lr_model_displayname} to project {project_id} in compartment {compartment_id}")
mc_model_lr = lr_model.save(project_id=project_id, 
                               compartment_id=compartment_id, 
                               display_name=lr_model_displayname,
                               description=lr_model_description,
                               freeform_tags={"Pipeline_run": pipelinerun_id},  # tag the model so it can be identified in the evaluation step
                               ignore_pending_changes=True)
print("Model OCID: ", lr_model.model_id)