#!/bin/bash --login

python /etc/datascience/run.py

exit $LastExitCode


