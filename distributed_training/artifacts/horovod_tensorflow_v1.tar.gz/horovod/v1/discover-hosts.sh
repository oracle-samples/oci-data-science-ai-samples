#!/bin/bash --login

export PYTHONPATH=$PYTHONPATH:/etc/datascience

python /etc/datascience/horovod/discover_workers.py

$@
