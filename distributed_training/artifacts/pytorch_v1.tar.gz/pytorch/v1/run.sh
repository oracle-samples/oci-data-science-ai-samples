#!/bin/bash --login

python /etc/datascience/run.py $OCI__ENTRY_SCRIPT_ARGS

exit $LastExitCode


