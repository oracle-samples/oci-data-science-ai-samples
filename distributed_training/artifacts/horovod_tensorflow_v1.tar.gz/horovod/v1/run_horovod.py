from ads.opctl.distributed.common.cluster_provider_factory import ClusterProviderFactory
from cluster_runner_horovod import ClusterRunnerHorovod
from horovod_provider import HorovodProvider

def main():
    ClusterProviderFactory.register("HOROVOD", HorovodProvider)
    ClusterRunnerHorovod(cluster_key="HOROVOD").run()

if __name__ == "__main__":
    main()