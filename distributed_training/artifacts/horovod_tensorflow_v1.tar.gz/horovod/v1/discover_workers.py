import json
import os
from urllib.parse import urlparse

import fsspec
from ads.common import auth as authutil

def get_oci_auth():
    if os.environ.get("OCI_IAM_TYPE", "resource_principal") == "resource_principal":
        authinfo = authutil.resource_principal()
    else:
        authinfo = authutil.api_keys()
    return authinfo

def discover_hosts():

    # Can't have any logging here. horovod breaks as it thinks they're all IPs
    work_dir = os.environ.get("OCI__WORK_DIR")
    jobDefID = os.environ.get("JOB_OCID")
    scheme = urlparse(work_dir).scheme
    authinfo = {}
    if scheme == "oci":
        authinfo = get_oci_auth()

    filesystem = fsspec.filesystem(scheme, **authinfo)  # FileSystem class corresponding to the URI scheme.

    path=f"{os.path.join(work_dir,jobDefID)}/WORKER*.json"
    files = filesystem.glob(path)
    ips = []
    for file in files:
        with filesystem.open(file, 'rb') as wcf:
            cfg_json = json.loads(wcf.read())
            ips.append(cfg_json['worker_ip'])
    print('\n'.join(ips))
    return ips

if __name__ == '__main__':
    # os.environ["OCI_IAM_TYPE"] = "api_key"
    # os.environ["WORK_DIR"] = "oci://dls-bucket@bigdatadatasciencelarge/daskcluster-testing/001"
    # os.environ["JOB_OCID"] = "ocid1.datasciencejob.oc1.iad.amaaaaaanif7xwiabcsocnzncbnn2g6vodld7e2gl24bhrxyaxb3363yz27a"
    ips = discover_hosts()