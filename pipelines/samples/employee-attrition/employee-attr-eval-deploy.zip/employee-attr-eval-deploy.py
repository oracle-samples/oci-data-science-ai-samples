# ===========================================================
# Employee attrition pipeline sample - evaluate all models and deploy best model step
#
# dependencies:
#    mlpipeline_data_helpers.py - helper functions to transfer data between steps
#
# Environment variables required:
#     DATA_LOCATION - Object storage bucket to use for temporary data transfer between steps
# 
# optional environment variables:
#     SKIP_MODEL_DEPLOY - to skip model deployment (for development phase)
#     DONT_DELETE_MODELS - skip model deletion from the catalog (for development phase)
#     CLEANUP_RESOURCES - delete the resources created during the pipeline - model deployment and model in the catalog
# ============================================================

import os
import sys
import subprocess

# update ADS
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'oracle-ads==2.6.1', '--upgrade'])

import ads
print("ADS version: ", ads.__version__)

def set_signer():
    RP = os.environ.get("OCI_RESOURCE_PRINCIPAL_VERSION", "UNDEFINED")
    if not RP or RP == "UNDEFINED":
        # Use api_key with config file
        print("using API key for auth")
        ads.set_auth(auth="api_key")
    else:
        # Use resource principal
        print("using Resource Principal for auth")
        ads.set_auth(auth="resource_principal")

        
set_signer()

from ads.catalog.model import ModelCatalog

# iterate on all the models from the pipeline run (based on tags) and find the best model
# ===========================================================================

pipelinerun_id = os.environ['PIPELINE_RUN_OCID']
compartment_id = os.environ['PIPELINE_COMPARTMENT_OCID']
project_id = os.environ['PIPELINE_PROJECT_OCID']

# get the models from the catalog
print("Retrieve the models from the catalog")
mc = ModelCatalog(compartment_id=compartment_id)
mc_list = mc.list_models(include_deleted=False)
# filter by pipeline run id
models = mc_list.filter(lambda x: ('Pipeline_run', pipelinerun_id) in x.freeform_tags.items())
# iterate over the list to find the best model
best_auc = 0.0
best_model = None
del_model = None
for x in models:
    m = mc.get_model(x.id)
    try:
       auc = float(m.metadata_custom['AUC'].value)
       print(f"model: {x.display_name}, AUC: {auc}")
    except ValueError:
        auc = 0.0
    if (auc > best_auc):
        print(f"Found new best model: {x.display_name}, AUC: {auc}")
        if best_model is not None:
            del_model = best_model   # delete the old best model
        best_model = m
        best_auc = auc
    else:
        del_model = m
    if os.environ.get("DONT_DELETE_MODELS") is not None and os.environ["DONT_DELETE_MODELS"] == "True":
        print("DONT_DELETE_MODELS = True. Skipping models deletion from model catalog.")
    else:
        if del_model is not None:
            # delete the model from the catalog
            print(f"Deleting model {del_model.display_name} from the catalog")
            mc.delete_model(del_model.id)        
try:
    print(f"Best model: {best_model.display_name} (AUC={best_model.metadata_custom['AUC'].value})")
except NameError:
    print("No models found")

# ====================================================================

# check if need to skip model deployment
if os.environ.get("SKIP_MODEL_DEPLOY") is not None and os.environ["SKIP_MODEL_DEPLOY"] == "True":
    print("Skipping model deployment")
    exit()

# deploy the model
#==========================================================

print(f"Deploying model {best_model.display_name} in project {project_id} in compartment {compartment_id}")

from ads.model.deployment import ModelDeployer

deployer = ModelDeployer()
deployment = deployer.deploy(
    model_id=best_model.id,
    display_name=f"Model Deployment of best model from pipeline run {pipelinerun_id}",
    instance_shape="VM.Standard2.1",
    instance_count=1,
    project_id=project_id,
    compartment_id=compartment_id
    # The following are optional
    #access_log_group_id="<ACCESS_LOG_GROUP_OCID>",
    #access_log_id="<ACCESS_LOG_OCID>",
    #predict_log_group_id="<PREDICT_LOG_GROUP_OCID>",
    #predict_log_id="<PREDICT_LOG_OCID>"
)

#===========================================================

# check if need to skip model deployment
if os.environ.get("CLEANUP_RESOURCES") is not None and os.environ["CLEANUP_RESOURCES"] == "True":
    print("Cleaning up resources")
    
    ## delete model deployment
    if (deployment is not None):        
        deployment.delete(wait_for_completion=True)

    ## delete model from catalog
    mc.delete_model(best_model.id)
