# ===========================================================
# Employee attrition pipeline sample - training XGBoost step
#
# dependencies:
#    mlpipeline_data_helpers.py - helper functions to transfer data between steps
#
# Environment variables required:
#     DATA_LOCATION - Object storage bucket to use for temporary data transfer between steps
# 
# optional environment variables:
#     SKIP_MODEL_SAVE - to skip saving the model to the model catalog (for development phase)
# ============================================================

import sys
import subprocess

# update ADS
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'oracle-ads==2.6.1', '--upgrade'])

# update onnxconverter_common:
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'onnxconverter_common==1.9.0', '--upgrade'])

# install xgboost:
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'xgboost'])

import io
import logging
import os
from os import path 

import ads 
print("ADS version: ", ads.__version__)

import pandas as pd
import numpy as np

from xgboost import XGBClassifier
from sklearn import model_selection
from sklearn.metrics import auc, roc_auc_score, log_loss, roc_curve

from ads.model.generic_model import GenericModel
from ads.common.model_metadata import UseCaseType
from ads.common.model_metadata import MetadataCustomCategory
from ads.common.auth import default_signer

def set_signer():
    RP = os.environ.get("OCI_RESOURCE_PRINCIPAL_VERSION", "UNDEFINED")
    if not RP or RP == "UNDEFINED":
        # Use api_key with config file
        print("using API key for auth")
        ads.set_auth(auth="api_key")
    else:
        # Use resource principal
        print("using Resource Principal for auth")
        ads.set_auth(auth="resource_principal")

        
set_signer()

# read the data
from mlpipeline_data_helpers import MLPipelineDataHelper

x_train_filename = MLPipelineDataHelper.get_pipeline_param('X_TRAIN_FILENAME')
try:
    X_train = pd.read_csv(x_train_filename, storage_options=default_signer())    
except FileNotFoundError:
    print(x_train_filename + " file not found")
    
y_train_filename = MLPipelineDataHelper.get_pipeline_param('Y_TRAIN_FILENAME')
try:
    y_train = np.ravel(pd.read_csv(y_train_filename, storage_options=default_signer()))
except FileNotFoundError:
    print(y_train_filename + " file not found")

x_test_filename = MLPipelineDataHelper.get_pipeline_param('X_TEST_FILENAME')
try:
    X_test = pd.read_csv(x_test_filename, storage_options=default_signer())    
except FileNotFoundError:
    print(x_test_filename + " file not found")

y_test_filename = MLPipelineDataHelper.get_pipeline_param('Y_TEST_FILENAME')
try:
    y_test = pd.read_csv(y_test_filename, storage_options=default_signer())    
except FileNotFoundError:
    print(y_test_filename + " file not found")

# Train XGBoost model
eval_set = [(X_train, y_train), (X_test, y_test)]
xgb_classifier = XGBClassifier(use_label_encoder=False, eval_metric=['auc','logloss'], eval_set=eval_set)

print("Fitting model")
xgb_classifier.fit(X_train, y_train)

Y_pred = xgb_classifier.predict_proba(X_test)
y_true = np.array(y_test)
y_scores = Y_pred[:, 1]
print("calculating roc curve")
fpr, tpr, _ = roc_curve(y_test, y_scores)
xgb_roc_auc = auc(fpr, tpr)

print('AUC score: %.3f' % xgb_roc_auc)

# Saving the model to the model catalog
from ads.common.model_artifact import ModelArtifact
from ads.common.model_export_util import prepare_generic_model
import joblib 

# Path to artifact directory for my sklearn model: 
xgb_model_path = "./model-artifact-xgb/"

# Creating the artifact template files in the directory: 
xgb_model_artifact = prepare_generic_model(xgb_model_path, 
                                         function_artifacts=False, 
                                         data_science_env=True,
                                         force_overwrite=True)

# Creating a joblib pickle object of the model: 
joblib.dump(xgb_classifier, os.path.join(xgb_model_path, "model.joblib"))

xgb_model = GenericModel(
    estimator=xgb_classifier, 
    artifact_dir=xgb_model_path
)
xgb_model.prepare(
    inference_conda_env="generalml_p37_cpu_v1",
    training_conda_env="generalml_p37_cpu_v1",
    use_case_type=UseCaseType.BINARY_CLASSIFICATION,
    X_sample=X_train,
    y_sample=y_train,
    force_overwrite=True
)

# set the AUC score on the model metadata
xgb_model.metadata_custom.add(key='AUC', value=f"{xgb_roc_auc}", category=MetadataCustomCategory.PERFORMANCE, replace=True)

# check if need to skip saving the model to the model catalog
if os.environ.get("SKIP_MODEL_SAVE") is not None and os.environ["SKIP_MODEL_SAVE"] == "True":
    print("Skipping model save to catalog")
    exit()

pipelinerun_id = os.environ['PIPELINE_RUN_OCID']
compartment_id = os.environ['PIPELINE_COMPARTMENT_OCID']
project_id = os.environ['PIPELINE_PROJECT_OCID']

# save the model to the catalog
xgb_model_displayname = "employee-attr-xgb"
xgb_model_description = "XGBoost model for employee attrition dataset"
print(f"Saving model {xgb_model_displayname} to project {project_id} in compartment {compartment_id}")
mc_model_xgb = xgb_model.save(project_id=project_id, 
                               compartment_id=compartment_id, 
                               display_name=xgb_model_displayname,
                               description=xgb_model_description,
                               freeform_tags={"Pipeline_run": pipelinerun_id},  # tag the model so it can be identified in the evaluation step
                               ignore_pending_changes=True)
print("Model OCID: ", xgb_model.model_id)