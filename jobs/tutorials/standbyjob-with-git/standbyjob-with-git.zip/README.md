# Standby Job with GitHub

Often during the development process it is more practicle to instead of start a new job on every code change, to regulary pull the code on a change.

This example shows how you could start a job that we call `Standby Job` which runs a script in a loop that monitors a pre-defined GitHub repository for code changes (check-in). If code change is avaiable it will pull it and execute it.

## Prerequisites

No specific pre-requirements, however we recommend you for local testing to install and run Conda environment.

## Build and Run

The code can be executed and tested locally before running as a Job on OCI Data Science Service.

### Setup Conda (optional, but recommended)

### Run locally

After successful conda setup and activate, you can run the example directly:

```bash
bash listener.sh
```

You should see output similar to this, if you run the code for first time:

```bash
set default git repo: https://github.com/lyudmil-pelov/standbyjob.git
set default entrypoint: test.py
set default pull interval of 10 seconds
Creating sync directory: /Users/lypelov/development/oci-data-science-ai-samples/jobs/tutorials/standbyjob-with-git/code
Sync directory created
Cloning into '/Users/lypelov/development/oci-data-science-ai-samples/jobs/tutorials/standbyjob-with-git/code'...
remote: Enumerating objects: 26, done.
remote: Counting objects: 100% (26/26), done.
remote: Compressing objects: 100% (26/26), done.
remote: Total 26 (delta 12), reused 0 (delta 0), pack-reused 0
Receiving objects: 100% (26/26), 6.88 KiB | 6.88 MiB/s, done.
Resolving deltas: 100% (12/12), done.
Starting hello.py
do something else here ...
Hello (Job)
Job Done.
```

After the first run, if you run the script again the output would change, because the code is already checkout the first time:

```bash
Sync Directory: /Users/lypelov/development/oci-data-science-ai-samples/jobs/tutorials/standbyjob-with-git/code
From https://github.com/lyudmil-pelov/standbyjob
 * branch            HEAD       -> FETCH_HEAD
Already up to date.
Starting hello.py
do something else here ...
Hello (Job)
Job Done.
From https://github.com/lyudmil-pelov/standbyjob
 * branch            HEAD       -> FETCH_HEAD
Already up to date.
```

... after which you will see regular pulls every `PULL_INTERVAL` (default 10s) time in seconds:

```bash
From https://github.com/lyudmil-pelov/standbyjob
 * branch            HEAD       -> FETCH_HEAD
Already up to date.
```

### Run as a job

Zip the code from withing the folder:

```bash
cd standbyjob-with-git
zip -r standbyjob-with-git.zip *.* -x ".*" -x "__MACOSX"
```

Create a job with the zip file.

On Job Run specify:

`JOB_RUN_ENTRYPOINT=listener.sh`

The script takes following env. variables, the default values are:

```ini
GIT_REPO=https://github.com/lyudmil-pelov/standbyjob.git
ENTRYPOINT=test.py
PULL_INTERVAL=10
```

Change those to point to your repository, main file of execution and pull interval.

Monitoring with the `ads opctl watch <job-run-ocid>` should show something like:

```bash

```