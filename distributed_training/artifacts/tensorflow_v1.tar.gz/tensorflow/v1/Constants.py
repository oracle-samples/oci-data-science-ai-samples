UNDEFINED_OCID = "Undefined"
DEFAULT_WORKER_PORT = "12345"
DEFAULT_WORKER_COUNT = 0
DEFAULT_PS_COUNT = 0

TF_CONFIG_BASE = {
    'cluster': {
        'worker': []
    },
    'task': {'type': 'worker', 'index': 0}
}

TF_CONFIG_PS = {
    "cluster": {
        'worker': [],
        'ps': []
    },
    "task": {"type": "", "index": 0}
}

WORKER_MODE = 'worker'
PS_MODE = 'ps'

cluster_config = {
    "ps": {
        "0" : "host:port",
        "1" : "host:port"
    },
    "worker": {
        "0": "host:port",
        "1": "host:port"
    }
}

