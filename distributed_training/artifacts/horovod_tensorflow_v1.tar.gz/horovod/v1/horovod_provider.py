import os
import random
import subprocess
from time import sleep, time
from discover_workers import discover_hosts
from ads.opctl.distributed.common.abstract_cluster_provider import ClusterProvider
from urllib.parse import urlparse
from ads.common import auth as authutil
import fsspec
from ads.jobs import Job


class HorovodProvider(ClusterProvider):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.code_execution_complete = False
        self.run_loop_till_sec = 3000
        self.loop_step_size = 10
        self.num_workers = int(self.expected_worker_count())
        self.worker_port = os.environ.get("WORKER_PORT", "12345")
        self.derived_slot, self.derived_max_np = self.parse_shape(os.environ.get("SHAPE"))
        self.min_np = str(max(int(os.environ.get("MIN_NP", "1")), 1))
        print("min_np: ", self.min_np)
        # ToDo To review / test
        self.max_np = str(min(max(int(os.environ.get("MAX_NP", self.derived_max_np)), int(self.num_workers)), int(self.derived_max_np)))
        print("max_np: ", self.max_np)
        self.slots = str(min(max(int(os.environ.get("SLOTS", self.derived_slot)), 1), self.derived_slot))
        print("slots: ", self.slots)
        self.np = str(self.num_workers * int(self.slots))
        print("np: ", self.np)
        self.start_timeout = str(max(int(os.environ.get("START_TIMEOUT", "600")), 600))
        self.horovod_args = os.environ.get("HOROVOD_ARGS")
        self.kwargs = os.environ.get("kwargs", os.environ.get("KWARGS"))
        self.training_script = os.environ["OCI__ENTRY_SCRIPT"]
        self.training_args = os.environ.get("OCI__ENTRY_SCRIPT_ARGS")
        self.enable_timeline = os.environ.get("ENABLE_TIMELINE")
        self.sync_dir = self.get_sync_dir(os.environ.get("OCI__SYNC_DIR"))
        print("sync dir:", self.sync_dir)
        self.stop_file_fail = "_".join([self.stop_file, "fail"])

    def get_sync_dir(self, sync_dir):
        if sync_dir:
            return sync_dir
        os.environ["OCI__SYNC_DIR"] = "/opt/ml"
        return os.environ["OCI__SYNC_DIR"]

    def stop(self):
        """
        Writes stop file and exits.
        """
        # TODO CHeck if this is MAIN process before writing. There can be concurrency issue and object storage might complain.
        stop_file = self.stop_file_fail if self.execution_failure else self.stop_file
        with fsspec.open(stop_file, "w") as sf:
            sf.write("stop")
        sleep(20)

    def basic_configuration(
        self,
    ) -> dict:
        config = {}
        config["main_ip" if self.mode == "MAIN" else "worker_ip"] = self.ip
        config["tmpdir"] = self.my_work_dir
        return config


    def start(self):
        if self.mode == "MAIN":  # Check if the docker is started in scheduler mode
            print(f"Starting main scheduler process", flush=True)
            self.start_main()
        elif self.mode == "WORKER":  # Check if the docker is staretd in worker mode
            print(f"Starting worker process", flush=True)
            self.start_worker()
        else:
            print(f"Not a valid mode: {self.mode}", flush=True)
            raise Exception("Not a valid mode")

    def configuration(self, conf: dict = {}) -> dict:
        hvd_config = {**self.basic_configuration(), **conf}
        if self.mode == "MAIN":
            hvd_config["SCHEDULER_IP"] = hvd_config["main_ip"]
        return hvd_config

    def check_cluster_status(self):
        print('checking cluster status', flush=True)
        workers = self.poll()
        print("received workers: ", workers, flush=True)
        cluster_ready = len(workers) >= int(self.num_workers) \
                        and not self.code_execution_complete
        print("cluster ready: ", cluster_ready, flush=True)
        return cluster_ready


    def run_code(self):
        """ This takes job run id and job_run from the node where job is running. Then runs horovodrun
        If Runnable, start python process. upate the execution state. While waiting to run, if the state becomes `tearable`, then stop
        """
        while True:
            if self.check_cluster_status():  # Now we need to run the horovod run command using subprocess
                cmd = ["horovodrun",
                       "-np", self.np,
                       "-p", self.worker_port,
                       "--min-np", self.min_np,
                       "--max-np", self.max_np,
                       "--host-discovery-script", "/etc/datascience/horovod/discover-hosts.sh",
                       "--slots", self.slots,
                       "--start-timeout", self.start_timeout
                       ]

                if self.horovod_args:
                    print("adding horovod_args")
                    cmd += self.horovod_args.split()

                if self.kwargs:
                    print("adding kwargs")
                    cmd += self.kwargs.split()

                if self.enable_timeline == "1":
                    print("enable_timeline")
                    cmd.extend(["--timeline-filename", self.sync_dir + "/timeline.json"])

                training_cmd = ["python", self.training_script]
                cmd += training_cmd

                if self.training_args:
                    print("adding training_args")
                    cmd += self.training_args.split()

                print(cmd, flush=True)
                ret = subprocess.run(cmd)
                if ret.returncode != 0:
                    raise Exception("horovodrun errored out...", ret)
                self.code_execution_complete = True
                break
            elif self.tearable():
                break
            elif time() - self.start_time > self.time_out:
                raise Exception(
                    f"Cluster not in `ready` state in {self.time_out} seconds. To change the timeout set env variable: `OCI__TIMEOUT` to desired value"
                )
            else:
                print(
                    f"Waiting for cluster to be in ready state for {time() - self.start_time} seconds. Time out: {self.time_out} seconds"
                )

    def start_main(self):
        print("start_scheduler")
        self.export_configuration(self.export_config_files())
        # Export the configuration details as environment variable
        self.run_code()


    def export_config_files(self):
        """
        By default only exports configuration generated by master. This behavior can be overridden.
        """
        configs = [self.config_file]
        return configs

    def start_worker(self):
        self.export_configuration(
            self.export_config_files())  # Export the configuration details as environment variable
        start_worker_file = "start_worker.sh"
        ret = subprocess.run(["sh", start_worker_file])
        print("Return code from the subprocess:", ret)
        if ret.returncode != 0:
            raise Exception("Error Starting Worker Process")
        self.worker()

    def worker(self):
        work_dir = self.work_dir
        jobDefID = self.jobDefID
        scheme = urlparse(self.work_dir).scheme
        authinfo = {}
        if scheme == "oci":
            authinfo = self.get_oci_auth()

        filesystem = fsspec.filesystem(scheme, **authinfo)  # FileSystem class corresponding to the URI scheme.
        path = f"{os.path.join(work_dir, jobDefID)}/stop"
        path_fail = f"{os.path.join(work_dir, jobDefID)}/stop_fail"
        path_scheduler_config= f"{os.path.join(work_dir, jobDefID)}/MAIN_config.json"
        while True:
            success = filesystem.glob(path)
            failure = filesystem.glob(path_fail)
            scheduler_config = filesystem.glob(path_scheduler_config)
            if len(success) > 0:
                print("Success stop file found. Exiting worker...", flush=True)
                break
            if len(failure) > 0:
                raise Exception("Failure stop file found. Exiting worker... Please check logs.")

            if  len(scheduler_config) ==  0 and time() - self.start_time > self.time_out:
                raise Exception(
                    f"Cluster not in `ready` state in {self.time_out} seconds. To change the timeout set env variable: `OCI__TIMEOUT` to desired value"
                )

            print("worker running...", flush=True)
            sleep(60)

    def poll(self) -> int:
        workers = []
        x = 6
        while x > 0:
            workers = discover_hosts()
            if len(workers) >= int(self.num_workers):
                print("Found ", len(workers), "workers. Scheduler can start", flush=True)
                break
            sleep(10)
            x -= 1
        return workers

    # This is just for local testing !
    def get_oci_auth(self):
        use_local_ip = os.environ.get("USE_LOCAL_IP")
        print(f"use_local_ip={use_local_ip}")
        return authutil.api_keys() if use_local_ip else super().get_oci_auth()

    def find_self_ip(self, authinfo):
        use_local_ip = os.environ.get("USE_LOCAL_IP")
        if use_local_ip:  # for docker-compose mode
            import socket
            hostname = socket.gethostname()
            IPAddr = socket.gethostbyname(hostname)
            print(f'local setup ip {IPAddr}')
            return IPAddr
        else:
            return super().find_self_ip(authinfo)

    def parse_shape(self, shape_var):
        slot = 1
        if shape_var:
            shape = shape_var.split('.')
            print("shape received: ", shape)
            slot = int(shape[2])  # num cpu on each box
        else:
            print("deriving from Job definition")
            job_ocid = os.environ["JOB_OCID"]
            jobDef = Job.from_datascience_job(job_ocid)
            print("Shape from JobDef: ", jobDef.infrastructure.shape_name)
            try:
                slot = int(jobDef.infrastructure.shape_name.split('.')[2])
            except:
                print("Exception parsing shape from JobRun infrastructure. Defaulting slot to 1")
                slot = 1
        # else:
        #     print("deriving from os")
        #     slot = os.cpu_count()
        print("ocpus:", slot)
        max_np = str(int(self.num_workers) * slot)
        print("max_np:", max_np)
        return slot, max_np
