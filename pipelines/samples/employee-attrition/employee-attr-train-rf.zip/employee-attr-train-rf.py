# ===========================================================
# Employee attrition pipeline sample - training random forest model step
#
# dependencies:
#    mlpipeline_data_helpers.py - helper functions to transfer data between steps
#
# Environment variables required:
#     DATA_LOCATION - Object storage bucket to use for temporary data transfer between steps
# 
# optional environment variables:
#     SKIP_MODEL_SAVE - to skip saving the model to the model catalog (for development phase)
# ============================================================

import sys
import io
import logging
import os
from os import path 

import pandas as pd
import numpy as np

from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import auc, roc_auc_score, roc_curve, recall_score, log_loss

import ads
print("ADS version (requires version 2.6.1 or above): ", ads.__version__)

from ads.model.generic_model import GenericModel
from ads.common.model_metadata import UseCaseType
from ads.common.model_metadata import MetadataCustomCategory
from ads.common.auth import default_signer

def set_signer():
    RP = os.environ.get("OCI_RESOURCE_PRINCIPAL_VERSION", "UNDEFINED")
    if not RP or RP == "UNDEFINED":
        # Use api_key with config file
        print("using API key for auth")
        ads.set_auth(auth="api_key")
    else:
        # Use resource principal
        print("using Resource Principal for auth")
        ads.set_auth(auth="resource_principal")

        
set_signer()

# read the data
from mlpipeline_data_helpers import MLPipelineDataHelper

x_train_filename = MLPipelineDataHelper.get_pipeline_param('X_TRAIN_FILENAME')
try:
    X_train = pd.read_csv(x_train_filename, storage_options=default_signer())    
except FileNotFoundError:
    print(x_train_filename + " file not found")
    
y_train_filename = MLPipelineDataHelper.get_pipeline_param('Y_TRAIN_FILENAME')
try:
    y_train = np.ravel(pd.read_csv(y_train_filename, storage_options=default_signer()))
except FileNotFoundError:
    print(y_train_filename + " file not found")

x_test_filename = MLPipelineDataHelper.get_pipeline_param('X_TEST_FILENAME')
try:
    X_test = pd.read_csv(x_test_filename, storage_options=default_signer())    
except FileNotFoundError:
    print(x_test_filename + " file not found")

y_test_filename = MLPipelineDataHelper.get_pipeline_param('Y_TEST_FILENAME')
try:
    y_test = pd.read_csv(y_test_filename, storage_options=default_signer())    
except FileNotFoundError:
    print(y_test_filename + " file not found")
    
# Train a random forest model
rf_classifier = RandomForestClassifier(class_weight = "balanced",
                                       random_state=7)
param_grid = {'n_estimators': [50, 75, 100, 125],
              'min_samples_split':[2,4,6],
              'min_samples_leaf': [1, 2, 4],
              'max_depth': [5, 10, 15]}

print("Running grid search and fitting the model...")
grid_obj = GridSearchCV(rf_classifier,
                        #iid=True,
                        return_train_score=True,
                        param_grid=param_grid,
                        scoring='roc_auc',
                        cv=5)

grid_fit = grid_obj.fit(X_train, y_train)
rf_opt = grid_fit.best_estimator_

rf_opt.fit(X_train, y_train) # fit optimised model to the training data
rf_probs = rf_opt.predict_proba(X_test) # predict probabilities
rf_probs = rf_probs[:, 1] # we will only keep probabilities associated with the employee leaving
rf_opt_roc_auc = roc_auc_score(y_test, rf_probs) # calculate AUC score using test dataset
print('AUC score (after model fit): %.3f' % rf_opt_roc_auc)

# Saving the model to the model catalog

from ads.common.model_artifact import ModelArtifact
from ads.common.model_export_util import prepare_generic_model
import joblib 

# Path to artifact directory for my sklearn model: 
rf_sklearn_path = "./model-artifact-rf/"

# Creating the artifact template files in the directory: 
rf_sklearn_artifact = prepare_generic_model(rf_sklearn_path, 
                                         function_artifacts=False, 
                                         data_science_env=True,
                                         force_overwrite=True)

# Creating a joblib pickle object of my random forest model: 
joblib.dump(rf_opt, os.path.join(rf_sklearn_path, "model.joblib"))

rf_generic_model = GenericModel(
    estimator=rf_opt, 
    artifact_dir=rf_sklearn_path
)
rf_generic_model.prepare(
    inference_conda_env="onnx113_p39_cpu_v1",
    training_conda_env="onnx113_p39_cpu_v1",
    use_case_type=UseCaseType.BINARY_CLASSIFICATION,
    X_sample=X_train,
    y_sample=y_train,
    force_overwrite=True
)

# set the AUC score on the model metadata
rf_generic_model.metadata_custom.add(key='AUC', value=f"{rf_opt_roc_auc}", category=MetadataCustomCategory.PERFORMANCE, replace=True)

# check if need to skip saving the model to the model catalog
if os.environ.get("SKIP_MODEL_SAVE") is not None and os.environ["SKIP_MODEL_SAVE"] == "True":
    print("Skipping model save to catalog")
    exit()

# save the model to the catalog
rf_model_displayname = "employee-attr-rf"
rf_model_description = "Random Forest model for employee attrition dataset"
pipelinerun_id = os.environ['PIPELINE_RUN_OCID']
compartment_id = os.environ['PIPELINE_COMPARTMENT_OCID']
project_id = os.environ['PIPELINE_PROJECT_OCID']
print(f"Saving model {rf_model_displayname} to project {project_id} in compartment {compartment_id}")
mc_model_rf = rf_generic_model.save(project_id=project_id, 
                               compartment_id=compartment_id, 
                               display_name=rf_model_displayname,
                               description=rf_model_description, 
                               freeform_tags={"Pipeline_run": pipelinerun_id},  # tag the model so it can be identified in the evaluation step
                               ignore_pending_changes=True)
print("Model OCID: ", rf_generic_model.model_id)