import os, json, subprocess
from time import time, sleep
import Constants
import fsspec
from ads.opctl.distributed.common.abstract_cluster_provider import ClusterProvider
import ads
import shlex
import threading


class TensorflowProvider(ClusterProvider):
    def __init__(self, *args, **kwargs):
        os.environ.pop('TF_CONFIG', None)
        print("ads version: ", ads.__version__)
        self.is_local = os.environ["JOB_OCID"] == Constants.UNDEFINED_OCID
        self.worker_port = os.environ.get("WORKER_PORT", Constants.DEFAULT_WORKER_PORT)

        super().__init__(*args, **kwargs)
        self.tf_config = Constants.TF_CONFIG_BASE
        self.jobDefID = os.environ.get("JOB_OCID")
        self.cluster_config = f"{os.path.join(self.work_dir, self.jobDefID)}/cluster.json"

        self.training_script = os.environ["OCI__ENTRY_SCRIPT"]
        self.training_args = os.environ.get("OCI__ENTRY_SCRIPT_ARGS")

    def find_self_ip(self, authinfo):
        if self.is_local:  # for docker-compose mode
            import socket
            hostname = socket.gethostname()
            IPAddr = socket.gethostbyname(hostname)
            print(f'local setup ip {IPAddr}')
            return IPAddr
        else:
            return super().find_self_ip(authinfo)

    def expected_worker_count(self, ):
        return int(os.environ.get("OCI__WORKER_COUNT", Constants.DEFAULT_WORKER_COUNT))

    def expected_ps_count(self):
        return int(os.environ.get("OCI__PS_COUNT", Constants.DEFAULT_PS_COUNT))

    def configuration(self, conf={}) -> dict:
        return {"OCI__MODE": os.environ["OCI__MODE"],
                "OCI__WORKER_IP": self.ip,
                "WORKER_PORT": self.worker_port
                }

    def write_cluster_config(self):
        files = []
        start_time = time()
        expected_config_count = self.expected_worker_count() + self.expected_ps_count() + 1
        while not len(files) >= expected_config_count:
            filesystem = self.stop_filesystem
            path = f"{os.path.join(self.work_dir, self.jobDefID)}/*config.json"
            print("checking configs in path:", path)
            files = filesystem.glob(path)
            print(files)
            print("len files:", len(files), " expected config count:", expected_config_count, flush=True)
            if time() - start_time > self.time_out:
                raise Exception(
                    "Timed out waiting to be in ready status. Likely cause configuration is missing in the `WORK_DIR`"
                )
            sleep(10)

        worker_ips = {}
        ps_ips = {}
        worker_count = 0
        ps_count = 0
        for file in files:
            with filesystem.open(file, 'rb') as wcf:
                cfg_json = json.loads(wcf.read())
                print(cfg_json)
                if cfg_json['OCI__MODE'] == 'MAIN':  # main = 0th worker called chief
                    worker_ips.setdefault(0, self.ip + ':' + self.worker_port)
                elif cfg_json['OCI__MODE'] == 'WORKER':
                    worker_count = worker_count + 1  # workers start from 1
                    worker_ips.setdefault(worker_count, cfg_json['OCI__WORKER_IP'] + ':' + cfg_json['WORKER_PORT'])
                elif cfg_json['OCI__MODE'] == 'PS':
                    ps_ips.setdefault(ps_count, cfg_json['OCI__WORKER_IP'] + ':' + cfg_json['WORKER_PORT'])
                    ps_count = ps_count + 1  # PS start from 0

        self.worker_ips = worker_ips
        self.ps_ips = ps_ips
        cluster_config = Constants.cluster_config
        cluster_config[Constants.PS_MODE] = ps_ips
        cluster_config[Constants.WORKER_MODE] = worker_ips

        print(f"Writing cluster configuration: {cluster_config}", flush=True)

        with fsspec.open(self.cluster_config, "w", **self.authinfo) as conf:
            conf.write(json.dumps(cluster_config))

    def start_main(self):
        self.write_cluster_config()


    def server_monitor(self):
        import psutil
        while not self.stop_filesystem.exists(self.stop_file):
            sleep(10)

        for proc in psutil.process_iter():
            try:
                cmd = proc.cmdline()
                if self.training_script in cmd :
                    print("Shutting down server as training has completed (or there has been an error)...")
                    proc.terminate()
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass
        sleep(5)


    def start_ps(self):
        thread = threading.Thread(target=self.server_monitor, name="server_monitor")
        thread.start()

    def start_worker(self):
        if self.expected_ps_count() > 0:
            thread = threading.Thread(target=self.server_monitor, name="server_monitor")
            thread.start()


    def ready(self):
        print("Checking cluster config: ", self.cluster_config, flush=True)
        return self.stop_filesystem.exists(self.cluster_config)

    def get_task_type(self, index):
        return 'chief' if index == 0 else 'worker'

    def create_tf_config_mwm(self, worker_ips):
        for index, ip_port in worker_ips.items():
            self.tf_config['cluster']['worker'].append(ip_port)
            if ip_port.split(':')[0] == self.ip and ip_port.split(':')[1] == self.worker_port:
                self.tf_config['task']['index'] = index
                self.tf_config['task']['type'] = "worker" # "worker"  # task_types are in small-case

    def create_tf_config_ps(self, worker_ips, ps_ips):
        for index, ip_port in worker_ips.items():
            # PS: worker doesn't run on coordinator
            if int(index) > 0:
                self.tf_config['cluster']['worker'].append(ip_port)
            else:
                self.tf_config['cluster']['chief'] = [ip_port]

            if ip_port.split(':')[0] == self.ip and ip_port.split(':')[1] == self.worker_port:
                self.tf_config['task']['index'] = '0' if int(index) == 0 else str(int(index) - 1)
                self.tf_config['task']['type'] = self.get_task_type(index)  # chief v/s worker

        if len(list(ps_ips)) > 0:
            self.tf_config['cluster']['ps'] = []
        for index, ip_port in ps_ips.items():
            self.tf_config['cluster']['ps'].append(ip_port)
            if ip_port.split(':')[0] == self.ip and ip_port.split(':')[1] == self.worker_port:
                self.tf_config['task']['index'] = index
                self.tf_config['task']['type'] = 'ps'  # task_types are in small-case

    def create_tf_config(self):
        if self.mode == 'MAIN':
            worker_ips = self.worker_ips
            ps_ips = self.ps_ips
        else:
            with fsspec.open(self.cluster_config, **self.authinfo) as conf:
                conf = json.loads(conf.read())
                worker_ips = conf['worker']
                ps_ips = conf['ps']
        print(f"worker_ips: {worker_ips}, ps_ips: {ps_ips}")

        if self.expected_ps_count() <= 0:
            self.create_tf_config_mwm(worker_ips)
        else:
            self.create_tf_config_ps(worker_ips, ps_ips)

        os.environ['TF_CONFIG'] = json.dumps(self.tf_config)
        print("TF_CONFIG: ", os.environ["TF_CONFIG"])


    def run_code(self):
        self.create_tf_config()
        cmd = self.profile_cmd()
        cmd.extend(["python", self.training_script])
        if self.training_args:
            cmd += shlex.split(self.training_args)

        print("Running: ", ' '.join(cmd), flush=True)

        training_start_time = time()
        ret = subprocess.run(cmd)

        if ret.returncode != 0:
            print(f"returncode : {ret.returncode}")
            if ret.returncode == -15:
                pass
            else:
                raise Exception("tensorflow distributed errored out...", ret)
        else:
            print("Training Time: ", time() - training_start_time, "seconds")

        self.code_execution_complete = True
        os.environ.pop('TF_CONFIG', None)

