#!/bin/bash --login

export PYTHONPATH=$PYTHONPATH:/etc/datascience
python /etc/datascience/cleanup.py

exit $LastExitCode


