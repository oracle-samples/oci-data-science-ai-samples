# ===========================================================
# Employee attrition pipeline sample - data processing step
#
# dependencies:
#    mlpipeline_data_helpers.py - helper functions to transfer data between steps
#
# Environment variables required:
#     DATA_LOCATION - Object storage bucket to use for temporary data transfer between steps
# 
# Optional Environment variables:
#     ATTRITION_DATA_PATH - Object storage location for the attrition data. if not defined the default will be used
#
# ============================================================

import sys
import subprocess

# update ADS
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'oracle-ads==2.6.1', '--upgrade'])

import io
import logging
import os
from os import path 

import ads 
print("ADS version: ", ads.__version__)

import pandas as pd
import numpy as np

from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import get_scorer

from ads.common.auth import default_signer

def set_signer():
    RP = os.environ.get("OCI_RESOURCE_PRINCIPAL_VERSION", "UNDEFINED")
    if not RP or RP == "UNDEFINED":
        # Use api_key with config file
        print("using API key for auth")
        ads.set_auth(auth="api_key")
    else:
        # Use resource principal
        print("using Resource Principal for auth")
        ads.set_auth(auth="resource_principal")

set_signer()

# read the data file from object storage
#===========================================
# use path from environment variable if defined, else use the default
attrition_path = "oci://hosted-ds-datasets@bigdatadatasciencelarge/synthetic/orcl_attrition.csv"
if os.environ.get('ATTRITION_DATA_PATH') is not None:
    attrition_path = os.environ['ATTRITION_DATA_PATH']
employees = pd.read_csv(attrition_path, storage_options=default_signer())
#===========================================

# data processing
#==================

df_HR = employees

# drop personal identification column
df_HR.drop(columns=["name"], inplace=True)

# Encoding
# Create a label encoder object
le = LabelEncoder()
# Label Encoding will be used for columns with 2 or less unique values
le_count = 0
for col in df_HR.columns[1:]:
    if df_HR[col].dtype == 'object':
        if len(list(df_HR[col].unique())) <= 2:
            le.fit(df_HR[col])
            df_HR[col] = le.transform(df_HR[col])
            le_count += 1
print('{} columns were label encoded.'.format(le_count))
# convert rest of categorical variable into dummy
df_HR = pd.get_dummies(df_HR, drop_first=True)

# Feature Scaling
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler(feature_range=(0, 5))
HR_col = list(df_HR.columns)
HR_col.remove('Attrition')
for col in HR_col:
    df_HR[col] = df_HR[col].astype(float)
    df_HR[[col]] = scaler.fit_transform(df_HR[[col]])
df_HR['Attrition'] = pd.to_numeric(df_HR['Attrition'], downcast='float')

#===================================

# Splitting data into training and testing sets
#====================================
# assign the target to a new dataframe and convert it to a numerical feature
target = df_HR['Attrition'].copy()

# let's remove the target feature and redundant features from the dataset
df_HR.drop(['Attrition', 'EmployeeNumber', 'Over18'], axis=1, inplace=True)
print('Size of Full dataset is: {}'.format(df_HR.shape))
from sklearn.model_selection import train_test_split
# Since we have class imbalance (i.e. more employees with turnover=0 than turnover=1)
# let's use stratify=y to maintain the same ratio as in the training dataset when splitting the dataset
X_train, X_test, y_train, y_test = train_test_split(df_HR,
                                                    target,
                                                    test_size=0.25,
                                                    random_state=7,
                                                    stratify=target)  

# Save the processed data to object storage
x_train_filename = os.environ["DATA_LOCATION"] + 'x_train.csv'
X_train.to_csv(x_train_filename, index=False, storage_options=default_signer())
y_train_filename = os.environ["DATA_LOCATION"] + 'y_train.csv'
y_train.to_csv(y_train_filename, index=False, storage_options=default_signer())
x_test_filename = os.environ["DATA_LOCATION"] + 'x_test.csv'
X_test.to_csv(x_test_filename, index=False, storage_options=default_signer())
y_test_filename = os.environ["DATA_LOCATION"] + 'y_test.csv'
y_test.to_csv(y_test_filename, index=False, storage_options=default_signer())

from mlpipeline_data_helpers import MLPipelineDataHelper
# set the filenames as parameters to the next steps
MLPipelineDataHelper.set_pipeline_param('X_TRAIN_FILENAME', x_train_filename)
MLPipelineDataHelper.set_pipeline_param('Y_TRAIN_FILENAME', y_train_filename)
MLPipelineDataHelper.set_pipeline_param('X_TEST_FILENAME', x_test_filename)
MLPipelineDataHelper.set_pipeline_param('Y_TEST_FILENAME', y_test_filename)