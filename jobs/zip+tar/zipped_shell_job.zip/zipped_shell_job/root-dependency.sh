#!/bin/bash

echo "Successfully calling from dependency in root directory.."