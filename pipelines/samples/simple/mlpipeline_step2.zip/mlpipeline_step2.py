import pandas as pd
import numpy as np
import os, io
import ads
from ads import set_auth
from ads.common.auth import default_signer
ads.set_auth(auth="resource_principal")

# import the helper functions
from mlpipeline_data_helpers import MLPipelineDataHelper

# function to create a dataframe with fake values for our workers
def generate_fake_data(num):
    fake = Faker()
    # lists to randomly assign to workers
    fake_data = [{'Worker ID':x+1000,
                  'Worker Name':fake.name(), 
                  'Hire Date':fake.date_between(start_date='-30y', end_date='today'),
                  'Team':np.random.choice([fake.color_name() for x in range(4)])} for x in range(num)]
        
    return fake_data

# read the parameter
num_of_workers = MLPipelineDataHelper.get_pipeline_param('NUMBER_OF_WORKERS')
print("Num of workers to create: ", num_of_workers)

# install Faker
import sys
import subprocess
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'Faker'])
from faker import Faker

# generate data to pass to the next step
workers_df = pd.DataFrame(generate_fake_data(num=num_of_workers))

# write the data to the requested filename in the object storage
workers_filename = 'workers_data.csv'
workers_file = os.environ["DATA_LOCATION"] + workers_filename
workers_df.to_csv(workers_file, index=False, storage_options=default_signer())

# set the filename as a parameter to the next step
MLPipelineDataHelper.set_pipeline_param('WORKERS_DATA_FILENAME', workers_filename)
